"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

exports.__esModule = true;
exports.default = void 0;

var _end = _interopRequireDefault(require("./end"));

exports.end = _end.default;

var _properties = _interopRequireDefault(require("./properties"));

exports.properties = _properties.default;
var _default = {
  end: _end.default,
  properties: _properties.default
};
exports.default = _default;