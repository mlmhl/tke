import ascending from "./ascending.js";

export default function(series) {
  return ascending(series).reverse();
}
