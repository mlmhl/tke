import { ClassNamesExport } from './types';

declare const classNamesDedupe: ClassNamesExport;

export = classNamesDedupe;
