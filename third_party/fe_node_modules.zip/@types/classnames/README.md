# Installation
> `npm install --save @types/classnames`

# Summary
This package contains type definitions for classnames (https://github.com/JedWatson/classnames).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/classnames.

### Additional Details
 * Last updated: Fri, 06 Mar 2020 21:10:49 GMT
 * Dependencies: none
 * Global values: `classNames`

# Credits
These definitions were written by [Dave Keen](http://www.keendevelopment.ch), [Adi Dahiya](https://github.com/adidahiya), [Jason Killian](https://github.com/JKillian), [Michal Adamczyk](https://github.com/mradamczyk), [Marvin Hagemeister](https://github.com/marvinhagemeister), [Josh McCullough](https://github.com/joshmccullough), and [uhyo](https://github.com/uhyo).
